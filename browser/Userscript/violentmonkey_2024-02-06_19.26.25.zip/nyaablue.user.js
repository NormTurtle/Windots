// ==UserScript==
// @name        nyaablue
// @namespace   garret's bad scripts
// @match       https://nyaa.si/*
// @grant       GM.xmlHttpRequest
// @grant       GM.setValue
// @grant       GM.getValue
// @version     0.3.3
// @author      garret
// @description brings blue to nyaav2 with seadex api
// @downloadURL https://fansubbing.427738.xyz/nyaablue.user.js
// ==/UserScript==


/* get best from seadex api, use api/search for the nyaa search value
get all nyaa links from ^
if link is present in page, make tr element class="info" (blue) */

var dex = "https://sneedex.moe/";

function actual_main(ids) {
    if (window.location.href.match("view")) {
        set_view_blue(ids)
    } else {
        set_search_blue(ids)
    }
}

function set_view_blue(ids) {
    let page_id = window
        .location
        .href
        .match("view/([0-9]+)")[1]
    if (ids.has(page_id)) {
        document.getElementsByClassName("panel-title")[0].parentNode.parentNode.className = "panel panel-info";
    }
}

function set_search_blue(ids) {
    let torrentlist = document.getElementsByClassName("torrent-list")[0].tBodies[0].children;
    for (const i of torrentlist) {
        let id = i
            .cells[1]
            .children[0]
            .attributes
            .href
            .value
            .match("view/([0-9]+)")[1]
        if (ids.has(id)) {
            i.className = "info"
        }
    }
}

function main() {
    GM.xmlHttpRequest({
        headers: {
            "Accept": "application/json",
            "User-Agent": "nyaablue.user.js"
        },
        method: "GET",
        url: encodeURI(dex + "api/public/nyaa"),
        onload: function(response) {
            let entries = JSON.parse(response.responseText);
            let ids = new Array()
            for (const i of entries) {
                for (const j of i.nyaaIDs) {
                  ids.push(String(j))
                }
            }
            GM.setValue("ids", ids)
            GM.setValue("last_update", Date.now())
            ids = new Set(ids)
            actual_main(ids) // i would've much preferred to just get the output as a variable in actual_main but GM_xhr says no
        }
    })
}

async function check_cache() {
    try {
        const last_update = await GM.getValue("last_update")
        if (typeof last_update !== "number") {
            throw "no_time"
        }
        if (Date.now() > last_update + 3600000) { // not updated in 1 hour
            ("cache old")
            main()
        } else {
            console.log("cache fine")
            const cached_ids = await GM.getValue("ids")
            if (typeof cached_ids !== "object") {throw "bad data"}
            actual_main(new Set(cached_ids))
        }
    } catch {
        console.log("ooer")
        main()
    }
}

// dark theme "support" (thanks olli)
document.head.insertAdjacentHTML('beforeend', '<style id="css_blue" type="text/css">body.dark .torrent-list > tbody > tr.info > td {color: inherit; background-color: rgba(0, 172, 255, 0.12);} body.dark .torrent-list > tbody > tr.info:hover > td {background-color: rgba(0, 172, 255, 0.18);} body.dark div.panel-info, body.dark div.panel-info > .panel-heading {border-color: #2c414b;} body.dark div.panel-info > .panel-heading {background-color: #2a3f4a;}</style>');

// yes its jank
// i blame greasemonkey
check_cache()
