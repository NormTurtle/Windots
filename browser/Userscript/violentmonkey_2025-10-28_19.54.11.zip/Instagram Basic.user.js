// ==UserScript==
// @name                Instagram Básico
// @namespace           http://linkme.bio/jhonpergon?userscript=insta_basic
// @version             1.4
// @description         Restaura o controle de vídeo simples para os vídeos do Instagram (mostrando tempo e barra de progresso) e permitindo click com botão esquerdo.
// @author              Jhon Pérgon

// @name:pt-BR    Instagram Básico
// @name:pt       Instagram Básico
// @name:es       Instagram Básico
// @name:en       Instagram Basic
// @name:fr       Instagram Basique
// @name:ru       Instagram Основы
// @name:ja       Instagram ベーシック
// @name:ko       Instagram 기본
// @name:zh-TW    Instagram 基本
// @name:zh-CN    Instagram 基本
// @name:id       Instagram Dasar
// @name:ug       Instagram ئاساسىي
// @name:ar       Instagram الأساسي
// @name:he       Instagram בסיסי
// @name:hi       Instagram बेसिक
// @name:th       Instagram พื้นฐาน
// @name:bg       Instagram Основни
// @name:ro       Instagram de bază
// @name:fi       Instagram Perus
// @name:it       Instagram di Base
// @name:el       Instagram Βασικό
// @name:eo       Instagram Baza
// @name:hu       Instagram Alapvető
// @name:nb       Instagram Grunnleggende
// @name:sk       Instagram Základný
// @name:sv       Instagram Grundläggande
// @name:sr       Instagram Osnovni
// @name:pl       Instagram Podstawowy
// @name:nl       Instagram Basis
// @name:de       Instagram Grundlegendes
// @name:da       Instagram Grundlæggende
// @name:cs       Instagram Základní
// @name:uk       Instagram Базовий
// @name:tr       Instagram Temel
// @name:vi       Instagram Cơ Bản
// @name:fr-CA    Instagram de Base

// @description:pt-BR         Restaura o controle de vídeo simples para os vídeos do Instagram após clicar para "remover o modo mudo" (mostrando tempo e barra de progresso) e permitindo clique com botão esquerdo.
// @description:pt            Restaura o controlo de vídeo simples para os vídeos do Instagram após clicar para "remover o modo mudo" (mostrando tempo e barra de progresso) e permitindo clique com o botão esquerdo.
// @description:es            Restaura el control de vídeo básico para los vídeos de Instagram después de hacer clic para "quitar el modo silencioso" (mostrando tiempo y barra de progreso) y permitiendo clic con el botón izquierdo.
// @description:en            Restores basic video control for Instagram videos after clicking to "unmute" (showing time and progress bar) and enabling left-click.
// @description:fr            Restaure le contrôle vidéo de base pour les vidéos Instagram après avoir cliqué pour "désactiver le mode silencieux" (affichage du temps et de la barre de progression) et autorise le clic gauche.
// @description:ru            Восстанавливает базовое управление видео для видеороликов Instagram после нажатия для "включения звука" (отображение времени и полосы прогресса) и разрешает левый щелчок.
// @description:ja            インスタグラムの動画に対する基本的なビデオコントロールを、"ミュート解除"クリック後に復元します（時間と進行状況バーを表示）左クリックを有効にします。
// @description:ko            인스타그램 동영상에 대한 기본 비디오 제어를 "음소거 해제" 클릭 후 복원합니다 (시간 및 진행률 표시) 왼쪽 클릭을 활성화합니다。
// @description:zh-TW         恢復 Instagram 影片的基本視頻控制，點擊“取消靜音”後（顯示時間和進度條）並啟用左鍵點擊。
// @description:zh-CN         恢复 Instagram 视频的基本视频控制，点击“取消静音”后（显示时间和进度条）并启用左键点击。
// @description:id            Mengembalikan kontrol video dasar untuk video Instagram setelah mengklik "menghapus mode bisu" (menampilkan waktu dan bilah kemajuan) dan mengaktifkan klik kiri.
// @description:ug            Instagram بىسىك فيديو كونترولنى، "جىمىش ھالىتىنى چىقىرىش" نى چېكىشتىن كېيىن قايتا قىلغانى (ۋاقت نۇسخىسى ۋە باراق بەلگىسىنى كۆرسەتكۈچى) ۋە سول توپ باسكۇنا ئېقىلىدۇ.
// @description:ar            استعادة التحكم الأساسي في الفيديو لمقاطع الفيديو في Instagram بعد النقر لإزالة "كتم الصوت" (عرض الوقت وشريط التقدم) وتمكين النقر بالزر الأيسر.
// @description:he            שחזור בקרת וידאו בסיסית עבור סרטוני Instagram לאחר לחיצה כדי "להסיר השתקה" (הצגת זמן וסרגל התקדמות) ואפשרות ללחוץ בצד שמאל.
// @description:hi            Instagram वीडियो के लिए मूल वीडियो नियंत्रण को "म्यूट हटाएं" क्लिक करने के बाद पुनर्स्थापित करें (समय और प्रगति पट्टी दिखाना) और बाएं क्लिक सक्षम करें।
// @description:th            คืนควบคุมวิดีโอพื้นฐานสำหรับวิดีโอ Instagram หลังจากคลิกเพื่อ "ยกเลิกการปิดเสียง" (แสดงเวลาและแถบความคืบหน้า) และเปิดใช้งานการคลิกซ้าย
// @description:bg            Възстановява основното видео управление за видео в Instagram след кликване за "премахване на заглушаването" (показване на времето и лентата за напредък) и активиране на щракване с левия бутон.
// @description:ro            Restabilește controlul de bază al videoclipului pentru videoclipurile Instagram după ce faci clic pentru "a dezactiva modul silențios" (afișarea timpului și a barei de progres) și permiteți clicul stânga.
// @description:fi            Palauttaa perusvideon hallinnan Instagram-videoille napsautuksen "mykistyksen poistaminen" jälkeen (näytä aika ja etenemispalkki) ja sallii vasemmanpuoleisen napsautuksen.
// @description:it            Ripristina il controllo video di base per i video di Instagram dopo aver fatto clic su "rimuovi muto" (mostra tempo e barra di avanzamento) e abilita il clic sinistro.
// @description:el            Επαναφέρει τον βασικό έλεγχο βίντεο για τα βίντεο του Instagram μετά από κλικ για "κατάργηση σίγασης" (εμφάνιση ώρας και μπάρας προόδου) και ενεργοποιεί το αριστερό κλικ.
// @description:eo            Restaŭras bazan videoregadon por Instagram videoj post klakado por "malŝalti muton" (montrado de tempo kaj progresbreto) kaj ebligado de maldekstra klako.
// @description:hu            Visszaállítja az alapvető videóvezérlést az Instagram videókhoz a "némítás eltávolítása" kattintás után (idő és előrehaladási sáv megjelenítése) és engedélyezi a bal kattintást.
// @description:nb            Gjenoppretter grunnleggende videokontroll for Instagram-videoer etter å ha klikket for å "fjern dempingen" (viser tid og fremdriftslinje) og aktiverer venstreklikk.
// @description:sk            Obnovuje základné ovládanie videa pre videá na Instagrame po kliknutí na "odstrániť stlmenie" (zobrazenie času a pruhu postupu) a umožňuje ľavé kliknutie.
// @description:sv            Återställer grundläggande videokontroll för Instagram-videor efter att ha klickat för att "ta bort ljudet" (visar tid och framstegsindikator) och aktiverar vänsterklick.
// @description:sr            Враћа основну контролу видеа за видео на Instagram након клика на "уклони режим без звука" (приказује време и траку напретка) и омогућава леви клик.
// @description:pl            Przywraca podstawową kontrolę wideo dla filmów na Instagramie po kliknięciu "usuń wyciszenie" (wyświetlanie czasu i paska postępu) i umożliwia kliknięcie lewym przyciskiem myszy.
// @description:nl            Herstelt basisvideobesturing voor Instagram-video's na het klikken op "dempen verwijderen" (weergeven van tijd en voortgangsbalk) en inschakelen van links klikken.
// @description:de            Stellt die grundlegende Videosteuerung für Instagram-Videos nach dem Klicken auf "Stummschaltung aufheben" wieder her (Anzeige von Zeit und Fortschrittsleiste) und ermöglicht Linksklick.
// @description:da            Gendanner grundlæggende videokontrol for Instagram-videoer efter at have klikket for at "fjerne lydløs tilstand" (viser tid og fremskridt bar) og aktiverer venstreklik.
// @description:cs            Obnoví základní ovládání videa pro videa na Instagramu po kliknutí na "zrušit ztlumení" (zobrazení času a pruhu postupu) a povolí levé kliknutí.
// @description:uk            Відновлює базове керування відео для відео в Instagram після натискання, щоб "зняти вимкнення звуку" (відображення часу і смуги прогресу) та дозволяє лівий клік.
// @description:tr            Instagram videoları için "sessizliği kaldırmak" tıklamasının ardından temel video kontrolünü geri yükler (zamanı ve ilerleme çubuğunu gösterme) ve sol tıklamayı etkinleştirir.
// @description:vi            Khôi phục điều khiển video cơ bản cho video Instagram sau khi nhấp vào "bỏ tắt tiếng" (hiển thị thời gian và thanh tiến trình) và cho phép nhấp chuột trái.
// @description:fr-CA         Restaure le contrôle vidéo de base pour les vidéos Instagram après avoir cliqué pour "désactiver le mode silencieux" (affichage du temps et de la barre de progression) et autorise le clic gauche.

// @match               https://www.instagram.com/*
// @icon                https://www.freeiconspng.com/thumbs/instagram-icon/instagram-icon--socialmedia-iconset--uiconstock-21.png
// @grant               none
// @license             MIT

// @compatible      chrome
// @compatible      firefox
// @compatible      opera
// @compatible      edge
// @compatible      safari
// @downloadURL https://update.greasyfork.org/scripts/494253/Instagram%20B%C3%A1sico.user.js
// @updateURL https://update.greasyfork.org/scripts/494253/Instagram%20B%C3%A1sico.meta.js
// ==/UserScript==

(function() {
    'use strict';

    let removeMute = false;

    function addControlsToVideos() {
      if(document.querySelector('.x1lliihq')){
        var videos = document.querySelectorAll('video');

      if(removeMute !== false){

        videos.forEach(function(video) {
            if (!video.controls) {
                video.controls = true;
                video.setAttribute('controlsList', 'nodownload');
                video.style.display = "inherit";
                video.style.position = "absolute";
                video.style.zIndex = "9999";

                video.removeEventListener('ended', '');
                video.removeEventListener('timeupdate', '');
                video.removeEventListener('seeking', '');
                video.removeEventListener('volumechange', '');

                video.removeEventListener('click', '');
                video.removeEventListener('mousedown', '');
                video.removeEventListener('down', '');
                video.removeEventListener('pointerdown', '');
                video.removeEventListener('mouseover', '');
                video.removeEventListener('keypress', '');
                video.removeEventListener('keydown', '');
                video.removeEventListener('load', '');
                video.removeEventListener('mouseenter', '');
                video.removeEventListener('mouseleave', '');
                video.removeEventListener('wheel', '');

                //video.autoplay = false;
                //video.volume = 1.0;
            }
            //video.muted = false;
        });

      }


        var btnsVolum = document.querySelectorAll('._acan._acao._acas._aj1-._ap30'); //x1i10hfl

        btnsVolum.forEach(function(volum) {
           let audd = volum.ariaLabel;
           if(audd){
             volum.addEventListener('click', function() {
               setTimeout(function(){
                 removeMute = true;
               },500);
            });
          }
          if(audd && removeMute == true){
            volum.style.display = 'none';
          }
        });

        var elements = document.querySelectorAll('*[style*="pointer-events: none"]');
        elements.forEach(function(element) {
            element.style.pointerEvents = 'auto';
        });

      }
    }

   addControlsToVideos();
   setInterval(addControlsToVideos, 1400);

})();
