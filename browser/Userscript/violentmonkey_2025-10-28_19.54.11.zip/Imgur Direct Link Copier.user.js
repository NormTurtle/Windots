// ==UserScript==
// @name         Imgur Direct Link Copier
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Add copy button for direct image/video links on Imgur
// @author       You
// @match        https://imgur.com/gallery/*
// @match        https://imgur.com/a/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function addCopyButton() {
        // Check if button already exists
        if (document.querySelector('#direct-link-copy-btn')) return;

        // Parse the media data from the page
        let mediaData;
        try {
            mediaData = JSON.parse(window.postDataJSON);
        } catch (e) {
            console.log('Could not parse media data');
            return;
        }

        // Create the copy button
        const copyBtn = document.createElement('button');
        copyBtn.id = 'direct-link-copy-btn';
        copyBtn.innerHTML = `
            <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                <path d="M4 1.5H3a2 2 0 0 0-2 2V14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-1v1h1a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1h1v-1z"/>
                <path d="M9.5 1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5h3zm-3-1A1.5 1.5 0 0 0 5 1.5v1A1.5 1.5 0 0 0 6.5 4h3A1.5 1.5 0 0 0 11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3z"/>
            </svg>
            Copy URL
        `;

        // Style the button to match Imgur's UI
        copyBtn.style.cssText = `
            background: #1bb76e;
            color: white;
            border: none;
            border-radius: 3px;
            padding: 8px 12px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 6px;
            margin: 8px 0;
            transition: background-color 0.2s;
        `;

        // Hover effect
        copyBtn.addEventListener('mouseenter', () => {
            copyBtn.style.backgroundColor = '#16a65c';
        });
        copyBtn.addEventListener('mouseleave', () => {
            copyBtn.style.backgroundColor = '#1bb76e';
        });

        // Click handler
        copyBtn.addEventListener('click', async () => {
            let urlToCopy = '';

            if (mediaData.media && mediaData.media.length > 0) {
                // For albums, copy the first media item
                const firstMedia = mediaData.media[0];
                urlToCopy = firstMedia.url;
            } else if (mediaData.cover) {
                // For single images
                urlToCopy = mediaData.cover.url;
            }

            if (urlToCopy) {
                try {
                    await navigator.clipboard.writeText(urlToCopy);

                    // Visual feedback
                    const originalText = copyBtn.innerHTML;
                    copyBtn.innerHTML = `
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                            <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                        </svg>
                        Copied!
                    `;
                    copyBtn.style.backgroundColor = '#16a65c';

                    setTimeout(() => {
                        copyBtn.innerHTML = originalText;
                        copyBtn.style.backgroundColor = '#1bb76e';
                    }, 2000);
                } catch (err) {
                    console.error('Failed to copy: ', err);
                    alert('Failed to copy URL');
                }
            } else {
                alert('No direct URL found');
            }
        });

        // Find a good place to insert the button
        const targetSelectors = [
            '[data-testid="post-actions"]',
            '.Post-actions',
            '.ImageContainer',
            '.Post'
        ];

        let insertTarget = null;
        for (const selector of targetSelectors) {
            insertTarget = document.querySelector(selector);
            if (insertTarget) break;
        }

        if (insertTarget) {
            insertTarget.appendChild(copyBtn);
        } else {
            // Fallback: add to body
            document.body.appendChild(copyBtn);
            copyBtn.style.position = 'fixed';
            copyBtn.style.top = '10px';
            copyBtn.style.right = '10px';
            copyBtn.style.zIndex = '9999';
        }
    }

    // Wait for page to load and try to add button
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', addCopyButton);
    } else {
        addCopyButton();
    }

    // Also try after a short delay for dynamic content
    setTimeout(addCopyButton, 1000);
    setTimeout(addCopyButton, 3000);
})();
